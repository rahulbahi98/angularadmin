import { log } from "util";

enum COSTING_TYPE { HEADER, LINE }
enum SPILT_TYPE { PERCENTAGE, QTY, AMOUNT }

export class BaseCosting {
    lineNo: number;
    company: string;
    businessUnit: string;
    location: string;
    costinValue: number = 0;
    spiltType: number;
    spiltValue: number;

}
export class ItemCosting extends BaseCosting {

}

export class InvoiceCosting extends BaseCosting {

}

export class InvoiceItem {
    lineNo: number;
    itemName: string;
    itemPrice: number = 0;
    itemQty: number = 0;
    itemTotal: number = this.itemPrice * this.itemQty;
    itemTaxTotal: number = 0;
    itemSubTotal: number = this.itemTotal + this.itemTaxTotal;
    itemCosting: ItemCosting[] = [];
    itemTaxes: ItemTaxes[] = [];
    itemDescription: string
    addTax(tax: ItemTaxes) {
        this.itemTaxes.push(tax)
        this.itemTaxTotal = this.itemTaxTotal + tax.taxAmmount
    }

    addCosting(costing: ItemCosting) {
        this.itemCosting.push(costing)
    }
}

export class Invoice {

    //    changeDetactor: Subject<void> = new Subject<void>()
    invoiceNumber: string;
    invoiceId: string;
    invoiceGrossTotal: number = 0;
    requester: string;
    invoiceItems: InvoiceItem[] = []
    invoiceTaxes: InvoiceTaxes[] = []
    invoiceCosting: InvoiceCosting[] = []
    COSTING_TYPE: COSTING_TYPE;
    SPILT_TYPE: SPILT_TYPE;
    invoiceTaxTotal: number;

    constructor() {
        //      this.changeDetactor.subscribe(this.callback)
    }

    callback() {
        console.log("someting has changed");
    }

    calculate(event: String) {


    }

    addItem(invoiceItem: InvoiceItem) {
        this.invoiceItems.push(invoiceItem)
        //    this.changeDetactor.next();
        this.invoiceGrossTotal = this.invoiceGrossTotal + invoiceItem.itemSubTotal;
    }

    removeItem(invoiceItem: InvoiceItem) {
        //this.invoiceItems.pop(invoiceItem)
    }

    addInvoiceCosting(invoiceCosting: InvoiceCosting) {

        this.invoiceCosting.push(invoiceCosting)
        //  this.changeDetactor.next();
    }

    validateCosting(invoiceCosting: InvoiceCosting) {

        console.log("ivnoice value", invoiceCosting.costinValue, this.invoiceCosting.length)
        if (this.invoiceCosting.length === 0)
            return invoiceCosting.costinValue === 100 ? true : false
        let total: number = invoiceCosting.costinValue
        let currentTotal = this.invoiceCosting.map(a => a.costinValue).reduce((total, b) => total + b)
        console.log(currentTotal)
        if (currentTotal != 100)
            return false;
        else
            return true;

    }

    addInvoiceTax(invoiceTax: InvoiceTaxes) {
        this.invoiceTaxes.push(invoiceTax)
        //this.changeDetactor.next();
    }

    setSpiltType(spiltType: SPILT_TYPE) {
        this.SPILT_TYPE = spiltType
        //this.changeDetactor.next();
    }

    setCostingType(costingType: COSTING_TYPE) {
        this.COSTING_TYPE = costingType
        //this.changeDetactor.next();
    }

    addItemTax(tax: ItemTaxes) {
        this.invoiceItems.forEach(item => {
            if (item.lineNo == tax.itemNo) {
                item.addTax(tax)
                //      this.changeDetactor.next();
                return;
            }
        });
    }

    addItemCosting(itemCosting: ItemCosting) {
        this.invoiceItems.forEach(item => {
            if (item.lineNo == itemCosting.lineNo) {
                item.addCosting(itemCosting)
                //    this.changeDetactor.next();
            }
        });
    }

    getCostingForItem(itemNo: number) {
        this.invoiceItems.forEach(e => {
            if (e.lineNo === itemNo) {
                this.calculateCostingForItem(e)
                return e.itemCosting;
            }
        })
    }

    calculateCostingForItem(e: InvoiceItem) {
        let invoiceTotal: number = this.invoiceGrossTotal;
        for (let index = 0; index < this.invoiceCosting.length; index++) {
            const item = this.invoiceCosting[index];
            item.costinValue = this.invoiceGrossTotal * (item.spiltValue * 100)
        }
    }

    calculateHeaderLevelCosting() {
        let invoiceTotal: number = 10;
        for (let index = 0; index < this.invoiceCosting.length; index++) {
            const item = this.invoiceCosting[index];
            item.costinValue = (invoiceTotal * (item.spiltValue / 100))
            console.log("from inside", item);
        }
        console.log(this.invoiceCosting)
    }
}

export class BaseTaxes {
    itemNo: number;
    taxname: string;
    taxRate: number;
    taxAmmount: number;
}

export class ItemTaxes extends BaseTaxes {

}

export class InvoiceTaxes extends BaseTaxes {

}

