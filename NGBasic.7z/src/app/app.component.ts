import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/Forms';
import { Invoice, InvoiceItem } from './InvoiceDetails';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  invoiceForm: FormGroup
  invoiceItemGroup: FormGroup
  invoiceTotal: number
  constructor(private invoice: Invoice) {

  }

  ngOnInit(): void {

    this.invoiceForm = this.createFormGroup()

    this.invoiceItemGroup = this.createItemFormGroup()
    this.invoiceItemGroup.valueChanges.subscribe((e) => {
    })
    this.invoiceForm.valueChanges.subscribe((value) => {
      this.invoice = value;
      this.invoice.COSTING_TYPE = value.COSTINGTYPE
      this.invoice.SPILT_TYPE = value.SPILT_TYPE
      console.log(this.invoice)
    })

  }

  createFormGroup() {
    return new FormGroup(
      {
        invoiceNumber: new FormControl(null, [Validators.required]),
        invoiceId: new FormControl(null, [Validators.required]),
        invoiceGrossTotal: new FormControl(0, [Validators.required]),
        requester: new FormControl(null, [Validators.required]),
        COSTINGTYPE: new FormControl(null, [Validators.required]),
        SPILTTYPE: new FormControl(null, [Validators.required]),
        invoiceTaxTotal: new FormControl(null, [Validators.required])
      }
    )
  }


  createItemFormGroup() {
    return new FormGroup(
      {
        lineNo: new FormControl(null, [Validators.required]),
        itemName: new FormControl(null, [Validators.required]),
        itemDescription: new FormControl(null, [Validators.required]),
        itemPrice: new FormControl(0, [Validators.required]),
        itemQty: new FormControl(0, [Validators.required]),
        itemTotal: new FormControl(0, null)
      }
    )
  }
  addItem() {
    this.invoiceTotal = this.invoiceItemGroup.value.itemPrice * this.invoiceItemGroup.value.itemQty
    this.invoice.addItem(this.invoiceItemGroup.value)
    console.log(this.invoice.invoiceItems)
    console.log("tst1", this.invoiceItemGroup.value)
    this.invoiceItemGroup.reset();
  }

  getInvoiceTotal() {
    return this.invoiceTotal;
  }

  getItemValue() {
    return this.invoiceItemGroup.value.itemPrice * this.invoiceItemGroup.value.itemQty
  }
}
