import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/Forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CountdownComponent } from './countdown/countdown.component';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';
import { DisplayComponent } from './display/display.component';
import { TimerComponent } from './timer/timer.component';
import { CreateInvoiceComponent } from './create-invoice/create-invoice.component';
import { InvoiceBasicDetailsComponent } from './invoice-basic-details/invoice-basic-details.component';
import { InvoiceItemsComponent } from './invoice-items/invoice-items.component';
import { ItemCostingComponent } from './item-costing/item-costing.component';
import { Invoice } from './InvoiceDetails';

@NgModule({
  declarations: [
    AppComponent,
    CountdownComponent,
    ProgressBarComponent,
    DisplayComponent,
    TimerComponent,
    CreateInvoiceComponent,
    InvoiceBasicDetailsComponent,
    InvoiceItemsComponent,
    ItemCostingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [Invoice],
  bootstrap: [AppComponent]
})
export class AppModule { }
