
enum COSTING_TYPE { HEADER, LINE }
enum SPILT_TYPE { PERCENTAGE, QTY, AMOUNT }


class BaseCosting {
    lineNo: number;
    company: string;
    businessUnit: string;
    location: string;
    costinValue: number = 0;
    spiltType: number;
    spiltValue: number;

}
class ItemCosting extends BaseCosting {

}

class InvoiceCosting extends BaseCosting {

}

class InvoiceItem {

    lineNo: number;
    itemName: string;
    itemPrice: number = 0;
    itemQty: number = 0;
    itemTotal: number = this.itemPrice * this.itemQty;
    itemTaxTotal: number = 0;
    itemSubTotal: number = this.itemTotal + this.itemTaxTotal;
    itemCosting: ItemCosting[] = [];
    itemTaxes: ItemTaxes[] = [];
    itemDescription: string

    addTax(tax: ItemTaxes) {
        this.itemTaxes.push(tax)
        this.itemTaxTotal = this.itemTaxTotal + tax.taxAmmount
    }

    addCosting(costing: ItemCosting) {
        this.itemCosting.push(costing)
    }
}

class Invoice {

    //    changeDetactor: Subject<void> = new Subject<void>()
    invoiceNumber: string;
    invoiceId: string;
    invoiceGrossTotal: number = 0;
    requester: string;
    invoiceItems: InvoiceItem[] = []
    invoiceTaxes: InvoiceTaxes[] = []
    invoiceCosting: InvoiceCosting[] = []
    COSTING_TYPE: COSTING_TYPE;
    SPILT_TYPE: SPILT_TYPE;
    invoiceTaxTotal: number;

    constructor() {
        //      this.changeDetactor.subscribe(this.callback)
    }

    callback() {
        console.log("someting has changed");
    }

    calculate(event: String) {


    }

    validateCostingNew() {

        if (this.COSTING_TYPE == COSTING_TYPE.HEADER) {

            if (SPILT_TYPE.PERCENTAGE === this.SPILT_TYPE) {
                let sum = this.invoiceCosting.map(a => a.spiltValue).reduce((a, b) => a + b)

                let total = this.invoiceCosting.map((e) => { return ((e.spiltValue / 100) * this.invoiceGrossTotal) }).reduce((a, b) => a + b)
                console.log("total", total)
                let totalCostingValue = this.invoiceCosting.map(a => a.costinValue).reduce((a, b) => a + b)
                if (sum != 100)
                    throw Error("Cositng value does not complete  100" + sum)

                if (total != this.invoiceGrossTotal)
                    throw Error("Value mismatch" + total)

                if (totalCostingValue != this.invoiceGrossTotal)
                    throw Error("Costing value should be equal to invoice gross total")


            }

        }
        else if (this.COSTING_TYPE === COSTING_TYPE.LINE) {

            switch (this.SPILT_TYPE) {
                case SPILT_TYPE.PERCENTAGE: {
                    console.log("per")
                    break
                }

                case SPILT_TYPE.AMOUNT: {
                    console.log("AMT")
                    break
                }

                case SPILT_TYPE.QTY: {
                    console.log("QTY")
                    break
                }
                default: { console.log("default"); break }
            }

        }
    }

    addItem(invoiceItem: InvoiceItem) {
        invoiceItem.itemSubTotal = invoiceItem.itemPrice * invoiceItem.itemQty
        this.invoiceItems.push(invoiceItem)
        this.invoiceGrossTotal = this.invoiceGrossTotal + invoiceItem.itemSubTotal;
    }

    removeItem(invoiceItem: InvoiceItem) {
        //this.invoiceItems.pop(invoiceItem)
    }

    addInvoiceCosting(invoiceCosting: InvoiceCosting) {
        this.invoiceCosting.push(invoiceCosting)
        //  this.changeDetactor.next();
    }

    validateCosting(invoiceCosting: InvoiceCosting) {

        console.log("ivnoice value", invoiceCosting.costinValue, this.invoiceCosting.length)
        if (this.invoiceCosting.length === 0)
            return invoiceCosting.costinValue === 100 ? true : false
        let total: number = invoiceCosting.costinValue
        let currentTotal = this.invoiceCosting.map(a => a.costinValue).reduce((total, b) => total + b)
        console.log(currentTotal)
        if (currentTotal != 100)
            return false;
        else
            return true;

    }

    addInvoiceTax(invoiceTax: InvoiceTaxes) {
        this.invoiceTaxes.push(invoiceTax)
        //this.changeDetactor.next();
    }

    setSpiltType(spiltType: SPILT_TYPE) {
        this.SPILT_TYPE = spiltType
        //this.changeDetactor.next();
    }

    setCostingType(costingType: COSTING_TYPE) {
        this.COSTING_TYPE = costingType
        //this.changeDetactor.next();
    }

    addItemTax(tax: ItemTaxes) {
        this.invoiceItems.forEach(item => {
            if (item.lineNo == tax.itemNo) {
                item.addTax(tax)
                //      this.changeDetactor.next();
                return;
            }
        });
    }

    addItemCosting(itemCosting: ItemCosting) {
        this.invoiceItems.forEach(item => {
            if (item.lineNo == itemCosting.lineNo) {
                item.addCosting(itemCosting)
                //    this.changeDetactor.next();
            }
        });
    }

    getCostingForItem(itemNo: number) {
        this.invoiceItems.forEach(e => {
            if (e.lineNo === itemNo) {
                this.calculateCostingForItem(e)
                return e.itemCosting;
            }
        })
    }

    calculateCostingForItem(e: InvoiceItem) {
        let invoiceTotal: number = this.invoiceGrossTotal;
        for (let index = 0; index < this.invoiceCosting.length; index++) {
            const item = this.invoiceCosting[index];
            item.costinValue = this.invoiceGrossTotal * (item.spiltValue * 100)
        }
    }

    calculateHeaderLevelCosting() {
        let invoiceTotal: number = 10;
        for (let index = 0; index < this.invoiceCosting.length; index++) {
            const item = this.invoiceCosting[index];
            item.costinValue = (invoiceTotal * (item.spiltValue / 100))
            console.log("from inside", item);
        }
        console.log(this.invoiceCosting)
    }
}

class BaseTaxes {
    itemNo: number;
    taxname: string;
    taxRate: number;
    taxAmmount: number;
}

class ItemTaxes extends BaseTaxes {

}

class InvoiceTaxes extends BaseTaxes {

}



let invoice: Invoice = new Invoice();
invoice.invoiceId = "1"
invoice.invoiceNumber = "Inv123456"
invoice.requester = "rahul@gmail.com"
invoice.SPILT_TYPE = SPILT_TYPE.PERCENTAGE
invoice.COSTING_TYPE = COSTING_TYPE.HEADER


let item1: InvoiceItem = new InvoiceItem()
item1.lineNo = 1
item1.itemName = "Computer"
item1.itemDescription = "Description"
item1.itemPrice = 10
item1.itemQty = 10
invoice.addItem(item1)
console.log(JSON.stringify(invoice))

item1 = new InvoiceItem()
item1.lineNo = 1
item1.itemName = "Computer"
item1.itemDescription = "Description"
item1.itemPrice = 10
item1.itemQty = 10
invoice.addItem(item1)
console.log(JSON.stringify(invoice))

console.log(invoice.invoiceGrossTotal);

let costing: InvoiceCosting = new InvoiceCosting()
costing.lineNo = 0
costing.costinValue = 50
costing.spiltValue = 50
invoice.addInvoiceCosting(costing)

costing = new InvoiceCosting()
costing.lineNo = 0
costing.costinValue = 140
costing.spiltValue = 50
invoice.addInvoiceCosting(costing)
invoice.validateCostingNew()


