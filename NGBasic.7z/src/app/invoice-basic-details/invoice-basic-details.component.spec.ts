import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceBasicDetailsComponent } from './invoice-basic-details.component';

describe('InvoiceBasicDetailsComponent', () => {
  let component: InvoiceBasicDetailsComponent;
  let fixture: ComponentFixture<InvoiceBasicDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceBasicDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceBasicDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
