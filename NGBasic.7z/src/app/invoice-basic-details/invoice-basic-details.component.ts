import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'invoice-basic-details',
  templateUrl: './invoice-basic-details.component.html',
  styleUrls: ['./invoice-basic-details.component.scss']
})
export class InvoiceBasicDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
