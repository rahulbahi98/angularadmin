import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'invoice-items',
  templateUrl: './invoice-items.component.html',
  styleUrls: ['./invoice-items.component.scss']
})
export class InvoiceItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
