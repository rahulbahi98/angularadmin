import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/Forms';
import { ItemCosting, Invoice, InvoiceItem, InvoiceCosting } from '../InvoiceDetails'
@Component({
  selector: 'item-costing',
  templateUrl: './item-costing.component.html',
  styleUrls: ['./item-costing.component.scss']
})
export class ItemCostingComponent implements OnInit {

  costingForm: FormGroup

  costings: ItemCosting[]

  defaultFormGroup: FormGroup
  constructor(private invoice: Invoice) { }

  ngOnInit() {
    this.defaultFormGroup = this.generateFormGroup();
    this.costingForm = new FormGroup({ "itemsCosting": new FormArray([this.defaultFormGroup]) })
    this.costingForm.valueChanges.subscribe((e) => console.log("valuechange", e))
    console.log((<FormArray>this.costingForm.get("itemsCosting")))
  }

  generateFormGroup() {
    return new FormGroup({
      id: new FormControl(null, Validators.required),
      company: new FormControl(null, Validators.required),
      businessUnit: new FormControl(null, Validators.required),
      location: new FormControl(null, Validators.required),
      costinValue: new FormControl(null, { validators: [Validators.required, this.validateCosting.bind(this)], updateOn: 'blur' }),
      spiltType: new FormControl(null, Validators.required),
      spiltValue: new FormControl(null, Validators.required)
    }, { updateOn: 'blur' });
  }

  onsubmit() {
    console.log(this.costingForm);
    let costing: ItemCosting[] = this.costingForm.value['itemsCosting'];
    //   console.log(costing.businessUnit)
    console.log("ocsting", costing[0].company);
    (<FormArray>this.costingForm.get("itemsCosting")).controls.push(this.generateFormGroup());

  }

  changeValue() {
    console.log(this.defaultFormGroup)
    this.defaultFormGroup.patchValue({
      "location": "changed"
    })


    this.invoice.invoiceId = '1'
    this.invoice.invoiceNumber = "123456"
    this.invoice.requester = "rahul@zycus.com"

    let invoiceItem = new InvoiceItem();
    invoiceItem.itemName = "Computer"
    invoiceItem.itemPrice = 10
    invoiceItem.itemQty = 10
    invoiceItem.lineNo = 1

    let invoicecosting: InvoiceCosting = new InvoiceCosting();
    invoicecosting.businessUnit = "PDT"
    invoicecosting.company = "ZYCUS"
    invoicecosting.location = "PUNE"
    invoicecosting.spiltValue = 40

    this.invoice.addItem(invoiceItem)


  }

  validateCosting(control: FormControl): { [s: string]: boolean } {
    if (this == undefined)
      return null
    let sum: number
    console.log("frp,Cpstomg", control.parent)
    let invoiceCosting = new InvoiceCosting()
    invoiceCosting.costinValue = control.value
    if (this.invoice != undefined)
      if (!this.invoice.validateCosting(invoiceCosting))
        return {
          "costingTotalErrot": true
        }
  }
}
