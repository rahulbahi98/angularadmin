import { Component, OnInit, Input, Output, EventEmitter, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { log } from 'util';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.scss']
})
export class TimerComponent implements OnInit {

  @Input() init: number

  @ViewChild('dialog') dialog

  searchBox: string
  timerRef: any;

  public counter: number = 0


  @Output() onDecrease = new EventEmitter<number>()

  @Output() onComplete = new EventEmitter<void>()

  public countdown: number

  states: string[] = ["MH"]
  constructor(private renderer: Renderer2) { }

  ngOnInit() {
    this.startCountdown()
  }

  startCountdown() {
    if (this.init && this.init > 0) {
      this.counter = this.init
      this.doCountdown()
    }
  }

  clearTimeOut() {
    if (this.timerRef) {
      clearTimeout(this.timerRef)
      this.timerRef = null
    }
  }
  doCountdown() {
    this.timerRef = setTimeout(() => {
      this.counter = this.counter - 1
      this.processCountdown()
    }, 1000);
  }

  processCountdown() {
    this.onDecrease.emit(this.counter)
    if (this.counter == 0) {
      this.onComplete.emit()
    }
    else {
      this.doCountdown()
    }
  }

  updateValues() {
    this.renderer.addClass(this.dialog.nativeElement, "open")
    this.states.push("UP", "GOA", "DL", "UK", "AP", "TN", "KL")

  }

  setInputValue(state) {

    this.states = []
    this.searchBox = state
    this.renderer.removeClass(this.dialog.nativeElement, "open")

  }


  update($event) {
    console.log($event);

  }
}
